# accordion
lovely jquery plugin
一个手风琴图片轮播jquery小插件(´・ω・)ﾉ

## 使用方法
在html文件head引入accordion.css、accordion.min.js（或accordion.js）
再添加脚本
<pre><code>
<script type="text/javascript">
    $(selector).accordion();
</script>
</code></pre>
大功告成(´・ω・)ﾉ

## 示例
可以下载accordion_example文件夹进行尝试~
